package com.ibm.test.dao;

import java.util.List ;
import java.util.ArrayList ;



import com.ibm.test.bean.*;

public interface DaoInterface {
	
	
	
	void storeEmployeeDetails(Employee emp);
	
	List<Employee> displayAllEmployeeDetails() ;

}
