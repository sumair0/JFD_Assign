package com.ibm.test.dao;

import java.util.ArrayList;
import java.util.List;

import com.ibm.test.bean.Employee;

public class DaoClass implements DaoInterface {
	
	List<Employee> arrEmp = new ArrayList<>(); 
	
	@Override
	public void storeEmployeeDetails(Employee emp) {
		arrEmp.add(emp) ;
	}
	
	@Override
	public List<Employee> displayAllEmployeeDetails(){
		return arrEmp ;
	}

}
