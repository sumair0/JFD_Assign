package com.ibm.test.service;

public class InvalidEmployeeException extends Exception {
	
	public static void main(String[] args) {
		System.out.println("Invalid Employee");
	}

}
