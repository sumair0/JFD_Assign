package com.ibm.test.service;

import java.util.List;

import com.ibm.test.bean.Employee ;
import com.ibm.test.dao.* ;




public class EmployeeServiceClass implements EmployeeService {
	
	
	DaoInterface dao = new DaoClass() ;
	 
	@Override 
	public String outputInsuranceScheme(int salary, String designation) {
		
		if( salary > 5000 && salary < 20000 ) {
			if( designation.equals("System Associate")) {
				return "Scheme_C" ;
			}
		}
		
		else if( salary >= 20000 && salary < 40000 ) {
			if( designation.equals("Programmer")) {
				return "Scheme_B" ;
			}
		}
		
		else if( salary >= 40000 ) {
			if( designation.equals("Manager")) {
				return "Scheme_A" ;
			}
		}
		
		else if( salary < 5000 ) {
			if( designation.equals("Clerk")) {
				return "No_Scheme" ;
			}
		}
		
		return "Invalid Entry" ;
		
	}

	@Override
	public void storeIntoDAO(Employee emp) {
		dao.storeEmployeeDetails(emp);	
		
	}

	@Override
	public List<Employee> displayEmployees() {
		return dao.displayAllEmployeeDetails() ;	
	}
	
	

}
