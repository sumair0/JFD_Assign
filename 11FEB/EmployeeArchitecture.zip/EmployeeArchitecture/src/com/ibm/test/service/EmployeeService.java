package com.ibm.test.service;


import java.util.List ;

import com.ibm.test.bean.Employee ;





public interface EmployeeService {
	
	String outputInsuranceScheme(int salary, String designation) ;
	
	
	void storeIntoDAO(Employee emp);

	List<Employee> displayEmployees();
	
	
}
