package com.ibm.test.bean;

public class Employee {
	
	private static int idCount = 1 ;

	int id;
	String name;
	public Employee(String name, int salary, String designation, String insuranceScheme) {
		this.id = idCount++;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	int salary;
	String designation;
	String insuranceScheme;

	public int getId() {
		return id;
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	@Override
	public String toString() {
		return "(ID: " + this.getId() + " , name: " + this.getName() + " ,Salary: " + this.getSalary() + " ,Salary: " + this.getSalary() + " ,Designation: " + this.getDesignation() + " ,InsuranceScheme: " + this.getInsuranceScheme() + ")" ;                                       
	}

}
