package com.ibm.test.ui;

import java.util.List ;

import java.util.Scanner;

import com.ibm.test.bean.Employee;
import com.ibm.test.service.EmployeeService;
import com.ibm.test.service.EmployeeServiceClass;
import com.ibm.test.service.InvalidEmployeeException;

public class Main {

	public static void main(String args[]) throws InvalidEmployeeException{

		Scanner scan = new Scanner(System.in);

		int choice = 0;

		final int CHOICE_ONE = 1, CHOICE_TWO = 2, CHOICE_THREE = 3;

		int id;
		String name;
		int salary;
		String designation;
		String insuranceScheme;

		EmployeeService empService = new EmployeeServiceClass();
		
		List<Employee> empList ;

		while (true) {
			System.out.println("\nThe services offered by this application currently are:\n" + "1)"
					+ "Get employee details from user.\n" + "2)"
					+ "Find the insurance scheme for an employee based on salary and designation.\n" + "3)"
					+ "Display " + "all the details of an employee");

			choice = scan.nextInt();

			if (choice == CHOICE_ONE) {

//				System.out.println("Enter the Employee ID");
//
//				id = scan.nextInt();

				System.out.println("Enter the Employee Name");

				name = scan.next();

				System.out.println("Enter the Salary");

				salary = scan.nextInt();
				
				System.out.println("Enter the designation") ;
				
				designation = scan.next();
				
				System.out.println("Enter the Scheme eg. 'Scheme_C', 'No_Scheme' ");
				
				insuranceScheme = scan.next() ; 
				
//				System.out.println(insuranceScheme);
				
				if( insuranceScheme.equals(empService.outputInsuranceScheme(salary, designation))) {
//					System.out.println(empService.outputInsuranceScheme(salary, designation));
					empService.storeIntoDAO(new Employee(name,salary,designation,insuranceScheme) );
				}
				else {
//					System.out.println(empService.outputInsuranceScheme(salary, designation));
					throw new InvalidEmployeeException() ;
				}
			}
			
			else if(choice == CHOICE_TWO) {
				System.out.println("Enter the Salary");

				salary = scan.nextInt();
				
				System.out.println("Enter the designation") ;
				
				designation = scan.next();
				
				System.out.println(empService.outputInsuranceScheme(salary, designation)) ;
			}
			
			else if(choice == CHOICE_THREE) {
				
				System.out.println("Enter the Employee Name");

				name = scan.next();
				
				empList = empService.displayEmployees();
				
				boolean flag = false ;
				
				for(Employee e : empList) {
					if ( (e.getName()).equals(name)) {
						System.out.println(e);
						flag = true ;
					}
				}
				
				if(flag == false) {
					throw new InvalidEmployeeException();
				}
				
				
				
			}

		}

	}

}
