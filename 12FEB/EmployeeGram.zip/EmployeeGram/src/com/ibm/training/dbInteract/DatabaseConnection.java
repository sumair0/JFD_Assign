package com.ibm.training.dbInteract;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection {

	Connection bdCon;
	PreparedStatement prepStat;

	 public DatabaseConnection() {
		try {
			this.bdCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_details", "root", "");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean addEmpRow(String name, int salary) {

		try {
			prepStat = this.bdCon.prepareStatement("INSERT INTO employee(Name,Salary) VALUES(?,?,?,?) ;");

			prepStat.setString(1, name);
			prepStat.setInt(2, salary);
			prepStat.setString(3, getDesignation(salary));
			prepStat.setString(4, getInsuranceScheme(salary));
			
			return true ;

		} catch (SQLException e) {
			e.getMessage();
		}
		
		return false ;

	}

	private String getDesignation(int salary) {
		if( salary > 5000 && salary < 20000 ) {
			return "System Associate" ; }
		
		else if( salary >= 20000 && salary < 40000 ) {
			return "Programmer" ; }
		
		else if( salary >= 40000 ) {
			return "Manager" ; }
		
		else if( salary <= 5000 ) {
			return "Clerk" ; }
		
		else {
			return "" ;
		}
	}

	private String getInsuranceScheme(int salary) {
		if( salary > 5000 && salary < 20000 ) {
			return "Scheme_C" ; }
		
		else if( salary >= 20000 && salary < 40000 ) {
			return "Scheme_B" ; }
		
		else if( salary >= 40000 ) {
			return "Scheme_A" ; }
		
		else if( salary <= 5000 ) {
			return "No_Scheme" ; }
		
		else {
			return "" ;
		}
		
		
		
			
		
	}

	public boolean findByDetails(int salary,String designation) {
		
		
		try {
			prepStat = this.bdCon.prepareStatement("SELECT * FROM employee WHERE Salary = ? AND Designation = ? ;") ;
			
			prepStat.setInt(1, salary);
			prepStat.setString(2, designation);
			
			ResultSet rs = prepStat.executeQuery() ;
			
			while(rs.next()) {
				System.out.print("|ID : " + rs.getInt("ID"));
				System.out.print("|Name : " + rs.getString("Name"));
				System.out.print("|Salary : " + rs.getInt("Salary"));
				System.out.print("|Designation : " + rs.getString("Designation"));
				System.out.print("|InsuranceScheme : " + rs.getString("InsuranceScheme"));
			}
			
			return true ;
			
			
		} catch (SQLException e) {
			e.getMessage() ;
		}
		
		return true ;
		
		

	}

	public void displayAllDetails() {
		
		try {
			prepStat = this.bdCon.prepareStatement("SELECT * FROM employee;") ;
						
			ResultSet rs = prepStat.executeQuery() ;
			
			while(rs.next()) {
				System.out.print("|ID : " + rs.getInt("ID"));
				System.out.print("|Name : " + rs.getString("Name"));
				System.out.print("|Salary : " + rs.getInt("Salary"));
				System.out.print("|Designation : " + rs.getString("Designation"));
				System.out.print("|InsuranceScheme : " + rs.getString("InsuranceScheme"));
			}
			
			
			
			
		} catch (SQLException e) {
			e.getMessage() ;
		}
	}

	public void updateEmpDetailsByIdName(int ID, String name) {
		try {
			prepStat = this.bdCon.prepareStatement("UPDATE employee SET Name = ? WHERE ID = ? ;") ;
		
		
		prepStat.setString(1, name);
		prepStat.setInt(2, ID);
		
        prepStat.execute() ;
		} catch (SQLException e) {
			e.getMessage() ;
		}
	}
	public void updateEmpDetailsByIdSalary(int ID, int salary) {
		try {
			prepStat = this.bdCon.prepareStatement("UPDATE employee SET Salary = ? WHERE ID = ? ;") ;
		
		
		prepStat.setInt(1, salary);
		prepStat.setInt(2, ID);
		
        prepStat.execute() ;
		} catch (SQLException e) {
			e.getMessage() ;
		}
	}
	public void updateEmpDetailsByIdDesignation(int ID, String designation) {
		
		try {
			prepStat = this.bdCon.prepareStatement("UPDATE employee SET Designation = ? WHERE ID = ? ;") ;
		
		
		prepStat.setString(1, designation);
		prepStat.setInt(2, ID);
		
        prepStat.execute() ;
		} catch (SQLException e) {
			e.getMessage() ;
		}
	}
	public void updateEmpDetailsByIdInsuranceScheme(int ID, String insch ) {
		
		try {
			prepStat = this.bdCon.prepareStatement("UPDATE employee SET InsuranceScheme = ? WHERE ID = ? ;") ;
		
		
		prepStat.setString(1, insch);
		prepStat.setInt(2, ID);
		
        prepStat.execute() ;
		} catch (SQLException e) {
			e.getMessage() ;
		}
		
		
	}

}
