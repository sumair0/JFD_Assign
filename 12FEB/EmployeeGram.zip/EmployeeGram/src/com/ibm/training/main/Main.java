package com.ibm.training.main;

import java.util.Scanner;

import com.ibm.training.dbInteract.DatabaseConnection;

public class Main {

	public static void main(String[] args) {

		DatabaseConnection database = new DatabaseConnection();

		Scanner scan = new Scanner(System.in);

		int id;
		String name;
		int salary;
		String designation;
		String insuranceScheme;
		
		int choice = 0, subChoice = 0;

		final int CHOICE_ONE = 1, CHOICE_TWO = 2, CHOICE_THREE = 3, CHOICE_FOUR = 4, CHOICE_FIVE = 5;

		while (true) {
			System.out.println("\nThe services offered by this application currently are:\n" + "1)"
					+ "Add employee details.\n" + "2)"
					+ "Find the insurance scheme for an employee based on salary and designation.\n" + "3)"
					+ "Display all the details of employees" + "\n4)Update details of inserted Employee Data"
					+ "\n5)Delete details of an Employee based on ID");

			

			choice = scan.nextInt();

			if (choice == CHOICE_ONE) {

				System.out.println("Please Enter the Employee name");

				name = scan.next();

				System.out.println("Please Enter Employee's salary");

				salary = scan.nextInt();

				database.addEmpRow(name, salary);
			}

			else if (choice == CHOICE_TWO) {

				System.out.println("Please Enter the Employee's salary");

				salary = scan.nextInt();

				System.out.println("Please Enter Employee's Designation");

				designation = scan.next();

				database.findByDetails(salary, designation);
			} 
			
			else if (choice == CHOICE_THREE) {

				database.displayAllDetails();
			}

			else if (choice == CHOICE_FOUR) {
				
				System.out.println("Enter the Employee ID which you want to update");
				
				id = scan.nextInt() ;

				System.out.println("What do you want to update?");

				while (true) {
					
					
					System.out.println("What do you want to update?\n1)Name\n2)Salary\n3)Designation\n4)InsuranceScheme\n ENTER ANY OTHER NUMBER TO EXIT IF DONE WITH ALL UPDATING");

					subChoice = scan.nextInt();
					
					if ( subChoice == CHOICE_ONE ) {
						System.out.println("Enter the name to be updated");
						
						name = scan.next() ;
						
						database.updateEmpDetailsByIdName(id,name) ;
					}
					
					else if ( subChoice == CHOICE_TWO ) {
						System.out.println("Enter the Salary to be updated");
						
						salary = scan.nextInt() ;
						
						database.updateEmpDetailsByIdSalary(id, salary);
					}
					
					else if ( subChoice == CHOICE_THREE ) {
						System.out.println("Enter the Designation to be updated");
						
						designation = scan.next() ;
						
						database.updateEmpDetailsByIdDesignation(id, designation);
					}
					
					else if ( subChoice == CHOICE_FOUR ) {
						System.out.println("Enter the insurance scheme to be updated as");
						
						insuranceScheme = scan.next() ;
						
						database.updateEmpDetailsByIdInsuranceScheme(id, insuranceScheme);
					}
					
					else {
						break ;
					}
				
				}
			}
			
			else if( choice == CHOICE_FIVE ) {
				
				
			}

		}

	}
}
